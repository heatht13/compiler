#ifndef SEMANTICS_H
#define SEMANTICS_H
#include "symbolTable.h"

extern int numErrors;
extern int numWarnings;
void traverseChildF(TreeNode *treeptr, SymbolTable *table);
void traverseSibF(TreeNode *treeptr, SymbolTable *table);
void traverseChildS(TreeNode *treeptr, SymbolTable *table);
void traverseSibS(TreeNode *treeptr, SymbolTable *table);
void fillTable(TreeNode *treeptr, SymbolTable *table);
void passTypes(TreeNode **treeptr, TreeNode **parent, SymbolTable *table);
void semanticAnalysis(TreeNode *treeptr, SymbolTable *table);
#endif
