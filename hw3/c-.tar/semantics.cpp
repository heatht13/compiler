#include "treeDef.h"
#include "semantics.h"
#include <string.h>
#include <stdlib.h>

TreeNode *temp = NULL;

void traverseChildF( TreeNode *treeptr, SymbolTable *table) {
    int i;
    for( i=0; i<MAXCHILDREN; i++) {
        fillTable(treeptr->child[i], table);
    }
    return;
}

void traverseSibF( TreeNode *treeptr, SymbolTable *table) {
    if( treeptr->sibling != NULL) {
        fillTable(treeptr->sibling, table);
    }
    return;
}

void traverseChildS( TreeNode *treeptr, SymbolTable *table) {
    int i;
    for( i=0; i<MAXCHILDREN; i++) {
        semanticAnalysis(treeptr->child[i], table);
    }
    return;
}

void traverseSibS( TreeNode *treeptr, SymbolTable *table) {
    if( treeptr->sibling != NULL) {
        semanticAnalysis(treeptr->sibling, table);
    }
    return;
}

void fillTable( TreeNode *treeptr, SymbolTable *table){
    //printf("Got to fillTable call\n");
    static int needCompound;
    table->debug(false);
    if(treeptr == NULL){
        return;
    }
    int i;

    switch(treeptr->nodeKind) {
//------------- Declarations -------------------
        case(DeclK):
            needCompound = 0;
            switch(treeptr->subkind.decl) {
                case(VarK):
                    //printf("%s\n", treeptr->attr.name);
                    table->insert(treeptr->attr.name, treeptr);
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(FuncK):
                    table->insert(treeptr->attr.name, treeptr);
                    table->enter(treeptr->attr.name);
                    needCompound = 1;
                    traverseChildF(treeptr, table);
                    //table->leave();
                    traverseSibF(treeptr, table);
                    break;
                case(ParamK):
                    table->insert(treeptr->attr.name, treeptr);
                    traverseChildF(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                default:
                    //DEBUGGING PURPOSES
                    printf("Error in fillTable call: DeclK is not of valid type.\n");
                    break;
            }
            break;
//------------- Statements ---------------------
        case(StmtK):
            switch(treeptr->subkind.stmt) {
                case(NullK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(IfK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(WhileK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(ForK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(CompoundK):
                    if(needCompound) {
                        //dont create scope, scope was already created by function decl
                        needCompound = 0;
                        traverseChildF(treeptr, table);
                    }
                    else {
                        table->enter("scope");
                        traverseChildF(treeptr, table);
                        table->leave();
                        traverseSibF(treeptr, table);
                    }
                    break;
                case(ReturnK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(BreakK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(RangeK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                default:
                    //Debugging Purposes
                    printf("Error in fillTable call: StmtK is not of valid type.\n");
                    break;
            }
            break;
//------------- Expressions -------------------
        case(ExpK):
            //printf("expK: %s\n", treeptr->attr.string);
            switch(treeptr->subkind.exp) {
                case(OpK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(ConstantK):
                        //traverseChildF(treeptr, table); //CONSTANT DONT HAVE CHILDREN
                        traverseSibF(treeptr, table);
                    break;
                case(IdK):
                    //printf("IdK: %s\n", treeptr->attr.name);
                    //temp = (TreeNode *)table->lookup(treeptr->attr.name);
                    //treeptr->expType = temp->expType;
                    //if(temp->type) {
                      // treeptr->type = strdup(temp->type);
                    //}
                    /*if(!temp) { 
                        treeptr->expType = UndefinedType;
                        treeptr->type = NULL;
                        treeptr->isArray = 0;
                        treeptr->isStatic = 0;
                        treeptr->isInit = 0;
                    }
                    else {
                        treeptr->expType = temp->expType;
                        treeptr->type = strdup(temp->type);
                        treeptr->isArray = temp->isArray;
                        treeptr->isStatic = temp->isStatic;
                        treeptr->isInit = temp->isInit;
                    }*/
                    //If ID array, which has children, this reverts to OpK exp on c-.y 476
                    //traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(AssignK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(InitK):
                    traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                case(CallK):
                    //traverseChildF(treeptr, table);
                    traverseSibF(treeptr, table);
                    break;
                default:
                    //Debugging Purposes
                    printf("Error in fillTable call: ExpK is not of valid type.\nExpK: %s", treeptr->attr.string);
                    break;
            }
            break;
        default:
            //Node is not of decl, stmt, or exp type
            break;
    }
    return;
}

void passTypes(TreeNode **treeptr, TreeNode **parent, SymbolTable *table) {

    /*if((*treeptr)->attr.name) {
        printf("Got to passTypes: %s\n", (*treeptr)->attr.name);
    }*/
    int i;
    temp = NULL;
    for( i=0; i<MAXCHILDREN; i++) {
        if((*treeptr)->child[i] != NULL) {
            passTypes(&(*treeptr)->child[i], &(*treeptr), table);
        }
        if((*treeptr)->sibling != NULL) {
            passTypes(&(*treeptr)->sibling, &(*parent), table);
        }
        else {
            if((*treeptr)->nodeKind == ExpK) {
                switch((*treeptr)->subkind.exp) {
                    case(OpK):
                        if(strcmp((*treeptr)->attr.string, (char*)"=") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"!=") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"<") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"<=") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)">") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)">=") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"+") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"-") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"*") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"/") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"%") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        } /*might be broken*/
                        else if(strcmp((*treeptr)->attr.string, (char*)"[") == 0) {
                            (*treeptr)->expType = (*treeptr)->child[0]->expType;
                            if((*treeptr)->child[0]->type) {
                                (*treeptr)->type = strdup((*treeptr)->child[0]->type);
                            }
                            (*treeptr)->isArray = (*treeptr)->child[0]->isArray; 
                            (*treeptr)->isStatic = (*treeptr)->child[0]->isStatic;
                            (*treeptr)->isInit = (*treeptr)->child[0]->isInit;
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"sizeof") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"?") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"chsign") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"not") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"and") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"or") == 0) {
                            (*treeptr)->expType = Boolean;
                            (*treeptr)->type = strdup((char *)"bool");
                        }

                        break;
                    case(AssignK):
                        if(strcmp((*treeptr)->attr.string, (char*)"++") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"--") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        } /*might be broken*/
                        else if(strcmp((*treeptr)->attr.string, (char*)"<-") == 0) {
                            (*treeptr)->expType = (*treeptr)->child[0]->expType;
                            if((*treeptr)->child[0]->type) {
                                (*treeptr)->type = strdup((*treeptr)->child[0]->type);
                            }
                            (*treeptr)->isArray = (*treeptr)->child[0]->isArray;
                            (*treeptr)->isStatic = (*treeptr)->child[0]->isStatic;
                            (*treeptr)->isInit = (*treeptr)->child[0]->isInit;
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"+=") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"-=") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                            //(*treeptr)->isStatic = (*treeptr)->child[0]->isStatic;
                            //(*treeptr)->isInit = (*treeptr)->child[0]->isInit;
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"*=") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                            //(*treeptr)->isStatic = (*treeptr)->child[0]->isStatic;
                            //(*treeptr)->isInit = (*treeptr)->child[0]->isInit;
                        }
                        else if(strcmp((*treeptr)->attr.string, (char*)"/=") == 0) {
                            (*treeptr)->expType = Integer;
                            (*treeptr)->type = strdup((char *)"int");
                            //(*treeptr)->isArray = (*treeptr)->child[0]->isArray;
                            //(*treeptr)->isStatic = (*treeptr)->child[0]->isStatic;
                            //(*treeptr)->isInit = (*treeptr)->child[0]->isInit;
                        }

                        break;
                    case(ConstantK):
                        (*parent)->expType = (*treeptr)->expType;
                        if((*treeptr)->type) {
                            (*parent)->type = strdup((*treeptr)->type);
                        }
                        break;
                    case(IdK):
                        temp = (TreeNode *)table->lookup((*treeptr)->attr.name);
                        if(!temp) {
                            (*treeptr)->expType = UndefinedType;
                            (*treeptr)->type = NULL;
                            (*treeptr)->isArray = 0;
                            (*treeptr)->isStatic = 0;
                            (*treeptr)->isInit = 0;
                        }
                        else {
                            (*treeptr)->expType = temp->expType;
                            if(temp->type) {
                                (*treeptr)->type = strdup(temp->type);
                            }
                            (*treeptr)->isArray = temp->isArray;
                            (*treeptr)->isStatic = temp->isStatic;
                            (*treeptr)->isInit = temp->isInit;
                            temp = NULL;
                        }
                        break;
                    case(InitK):
                        (*treeptr)->expType = (*treeptr)->child[0]->expType;
                        if((*treeptr)->child[0]->type) {
                            (*treeptr)->type = strdup((*treeptr)->child[0]->type);
                        }
                        (*treeptr)->isArray = (*treeptr)->child[0]->isArray;
                        (*treeptr)->isStatic = (*treeptr)->child[0]->isStatic;
                        (*treeptr)->isInit = (*treeptr)->child[0]->isInit;
                        break;
                    case(CallK):
                        temp = (TreeNode *)table->lookup((*treeptr)->attr.name);
                        if(!temp) {
                            (*treeptr)->expType = UndefinedType;
                            (*treeptr)->type = NULL;
                            (*treeptr)->isArray = 0;
                            (*treeptr)->isStatic = 0;
                            (*treeptr)->isInit = 0;
                        }
                        else {
                            (*treeptr)->expType = temp->expType;
                            if(temp->type) {
                                (*treeptr)->type = strdup(temp->type);
                            }
                            (*treeptr)->isArray = temp->isArray;
                            (*treeptr)->isStatic = temp->isStatic;
                            (*treeptr)->isInit = temp->isInit;
                        }
                        break;
                    default:
                            printf("This print ss default in passType.\n");
                        break;
                }
            }
        }
    }
}
 
void semanticAnalysis( TreeNode *treeptr, SymbolTable *table){

    static int needCompound;
    static int expType0 = -1;
    static int expType1 = -1;
    table->debug(false);
    if(treeptr == NULL){
        return;
    }
    int i;

    switch(treeptr->nodeKind) {
//------------- Declarations -------------------
        case(DeclK):
            switch(treeptr->subkind.decl) {
                needCompound = 0;
                case(VarK):
                    if(!table->insert(treeptr->attr.name, treeptr)) {
                        printf("ERROR(%d): Symbol \'%s\' is already declared.\n", treeptr->line, treeptr->attr.name);
                        numErrors++;
                    }
                    //only varDeclInit can have children and I havent seen this yet
                    //printf("Var Info: type: %s ID: %s isArray: %d\n", treeptr->type, treeptr->attr.name, treeptr->isArray);
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(FuncK):
                    if( !table->insert(treeptr->attr.name, treeptr)) {
                        printf("ERROR(%d): Symbol \'%s\' is already declared.\n", treeptr->line, treeptr->attr.name);
                        numErrors++;
                    }
                    table->enter(treeptr->attr.name);
                    needCompound = 1;
                    traverseChildS(treeptr, table);
                    table->leave();
                    traverseSibS(treeptr, table);
                    break;
                case(ParamK):
                    if( !table->insert(treeptr->attr.name, treeptr)) {
                        printf("ERROR(%d): Symbol \'%s\' is already declared.\n", treeptr->line, treeptr->attr.name);
                        numErrors++;
                    }
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                default:
                    //Debugging Purposes
                    printf("Error: DeclK is not of valid type.\n");
                    break;
            }
            break;
//------------- Statements ---------------------
        case(StmtK):
            switch(treeptr->subkind.stmt) {
                case(NullK):
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(IfK):
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(WhileK):
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(ForK):
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(CompoundK):
                    if(needCompound) {
                        //dont create scope, scope was already created by function decl
                        needCompound = 0;
                        traverseChildS(treeptr, table);
                    }
                    else {
                        table->enter("scope");
                        traverseChildS(treeptr, table);
                        table->leave();
                        traverseSibS(treeptr, table);
                    }
                    break;
                case(ReturnK):
                    if( treeptr->child[0]->isArray) {
                        printf("Cannot return an array.\n");
                    }
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(BreakK):
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(RangeK):
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                default:
                    //Debugging Purposes
                    printf("StmtK is not of valid type.\n");
                    break;
            }
            break;
//------------- Expressions -------------------
        case(ExpK):
            if(treeptr->child[0]) {
            expType0 = treeptr->child[0]->expType;
            //type0 = strdup(treeptr->child[0]->type);
            }
            else {
                expType0 = -1;
            }
            if(treeptr->child[1]) {
            expType1 = treeptr->child[1]->expType;
            //type1 = strdup(treeptr->child[1]->type);
            }
            else {
                expType1 = -1;
            }
            switch(treeptr->subkind.exp) {
                case(OpK):
                    if(strcmp(treeptr->attr.string, (char*)"=") == 0) {
                        //can have arrays, nbut both must be arrays
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(treeptr->child[0]->isArray ^ treeptr->child[1]->isArray) {
                            if(treeptr->child[0]->isArray) {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                            else {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                        }
                        else if(expType0 != expType1) {
                            printf("ERROR(%d): \'%s\' requires operands of the same type but lhs is type %s and rhs is type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char*)"!=") == 0) {
                        //can have arrays
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(treeptr->child[0]->isArray ^ treeptr->child[1]->isArray) {
                            if(treeptr->child[0]->isArray) {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                            else {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                        }
                        else if(expType0 != expType1) {
                            printf("ERROR(%d): \'%s\' requires operands of the same type but lhs is type %s and rhs is type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char*)"<")== 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(treeptr->child[0]->isArray ^ treeptr->child[1]->isArray) {
                            if(treeptr->child[0]->isArray) {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                            else {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                        }
                        else if(expType0 != expType1) {
                            printf("ERROR(%d): \'%s\' requires operands of the same type but lhs is type %s and rhs is type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char*)"<=") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(treeptr->child[0]->isArray ^ treeptr->child[1]->isArray) {
                            if(treeptr->child[0]->isArray) {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                            else {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                        }
                        else if(expType0 != expType1) {
                            printf("ERROR(%d): \'%s\' requires operands of the same type but lhs is type %s and rhs is type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char*)">") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(treeptr->child[0]->isArray ^ treeptr->child[1]->isArray) {
                            if(treeptr->child[0]->isArray) {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                            else {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                        }
                        else if(expType0 != expType1) {
                            printf("ERROR(%d): \'%s\' requires operands of the same type but lhs is type %s and rhs is type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char*)">=") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(treeptr->child[0]->isArray ^ treeptr->child[1]->isArray) {
                            if(treeptr->child[0]->isArray) {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                            else {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                        }
                        else if(expType0 != expType1) {
                            printf("ERROR(%d): \'%s\' requires operands of the same type but lhs is type %s and rhs is type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"+") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray || treeptr->child[1]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if( expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"-") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray || treeptr->child[1]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"*") == 0) {
                        if(treeptr->child[1] != NULL) {
                            if( expType0 == UndefinedType || expType1 == UndefinedType) {
                                //Bypass any errors
                            }
                            else if( treeptr->child[0]->isArray || treeptr->child[1]->isArray) {
                                printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                            }
                            else if(expType0 != Integer) {
                                printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                                numErrors++;
                            }
                            else if(expType1 != Integer) {
                                printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                                numErrors++;
                            }
                        }
                        else  {
                            printf("Debugging Note: this token is reserved for binary multiplication. treeptr->attr.string (or token-tokenstr) should be \"sizeof\" here\n");
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"/") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray || treeptr->child[1]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"%") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray || treeptr->child[1]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"[") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(!treeptr->child[0]->isArray) {
                            printf("ERROR(%d): Cannot index nonarray \'%s\'.\n", treeptr->line, treeptr->child[0]->attr.name);
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): Array \'%s\' should be indexed by type int but got type %s.\n", treeptr->line, treeptr->child[0]->attr.name, treeptr->child[1]->type);
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"sizeof") == 0) { //not done
                        if( expType0 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(!treeptr->child[0]->isArray) {
                            printf("ERROR(%d): The operation \'%s\' only works with arrays.\n", treeptr->line, treeptr->attr.string);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"?") == 0) {
                       if( expType0 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): Unary \'%s\' requires an operand of type int but was given type %s.\n", treeptr->child[0]->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"chsign") == 0) {
                        if( expType0 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): Unary \'%s\' requires an operand of type int but was given type %s.\n", treeptr->child[0]->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"not") == 0) {
                        if( expType0 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Boolean) {
                            printf("ERROR(%d): Unary \'%s\' requires an operand of type bool but was given type %s.\n", treeptr->child[0]->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"and") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray || treeptr->child[1]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Boolean) {
                            printf("ERROR(%d): \'%s\' requires operands of type bool but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Boolean) {
                            printf("ERROR(%d): \'%s\' requires operands of type bool but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"or") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray || treeptr->child[1]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Boolean) {
                            printf("ERROR(%d): \'%s\' requires operands of type bool but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Boolean) {
                            printf("ERROR(%d): \'%s\' requires operands of type bool but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    break;
                case(ConstantK):
                        //traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    break;
                case(IdK):
                    temp = (TreeNode *)table->lookup(treeptr->attr.name);
                    if(!temp) {
                        printf("ERROR(%d): Symbol \'%s\' is not declared.\n", treeptr->line, treeptr->attr.name);
                        treeptr->expType = UndefinedType;
                        numErrors++;
                    }
                    else {
                        treeptr->expType = temp->expType;
                        //printf("this shoudln't print but %d\n", treeptr->expType);
                        if(temp->type) {
                            treeptr->type = strdup(temp->type);
                        }
                    }
                    //Ids should not have children or siblings;
                    //If ID array, which has children, this reverts to OpK exp on c-.y 476
                    //traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(AssignK):
                    if(strcmp(treeptr->attr.string, (char *)"++") == 0) {
                        if( expType0 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): Unary \'%s\' requires an operand of type int but was given type %s.\n", treeptr->child[0]->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"--") == 0) {
                        if( expType0 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): Unary \'%s\' requires an operand of type int but was given type %s.\n", treeptr->child[0]->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char*)"<-")  == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if(treeptr->child[0]->isArray ^ treeptr->child[1]->isArray) {
                            if(treeptr->child[0]->isArray) {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                            else {
                                printf("ERROR(%d): \'%s\' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", treeptr->line, treeptr->attr.string);
                                numErrors++;
                            }
                        }
                        else if(expType0 != expType1) {
                            printf("ERROR(%d): \'%s\' requires operands of the same type but lhs is type %s and rhs is type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"+=") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"-=") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"*=") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    else if(strcmp(treeptr->attr.string, (char *)"/=") == 0) {
                        if( expType0 == UndefinedType || expType1 == UndefinedType) {
                            //Bypass any errors
                        }
                        else if( treeptr->child[0]->isArray) {
                            printf("Error(%d): The operation \'%s\' does not work with arrays.\n", treeptr->line, treeptr->attr.string);
                        }
                        else if(expType0 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but lhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[0]->type);
                            numErrors++;
                        }
                        else if(expType1 != Integer) {
                            printf("ERROR(%d): \'%s\' requires operands of type int but rhs is of type %s.\n", treeptr->line, treeptr->attr.string, treeptr->child[1]->type);
                            numErrors++;
                        }
                        traverseChildS(treeptr, table);
                        traverseSibS(treeptr, table);
                    }
                    break;
                case(InitK):
                    traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                case(CallK):
                    temp = (TreeNode *)table->lookup(treeptr->attr.name);
                    if(!temp) {
                        printf("ERROR(%d): Symbol \'%s\' is not declared.\n", treeptr->line, treeptr->attr.name);
                        treeptr->expType = UndefinedType;
                        numErrors++;
                    }
                    else {
                        treeptr->expType = temp->expType;
                        if(temp->type) {
                            treeptr->type = strdup(temp->type);
                        }
                    }
                    //traverseChildS(treeptr, table);
                    traverseSibS(treeptr, table);
                    break;
                default:
                    //Debugging Purposes
                    printf("Error: ExpK is not of valid type.\nExpK: %s", treeptr->attr.string);
                    break;
            }
            break;
        default:
            //Node is not of decl, stmt, or exp type
            printf("This print is default in semanticAnalysis.\n");
            break;
    }
    return;
}
